package com.internal.scripts;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.internal.pages.AgentFrontEnd;
import com.internal.pages.CustomerFrontEnd;
import com.internal.utilities.ExcelUtility;

import net.jodah.failsafe.internal.util.Assert;

public class TestClassAgent extends TestBase{
AgentFrontEnd objAgent;

	
	@Test(priority=1)
    public void verifyAgentLogin() throws IOException, InterruptedException  {
    //Create Login Page object
	
		objAgent = new AgentFrontEnd(driver);
    //login to application clickLoginLink
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver, 20); 
	//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
	objAgent.clickLoginLink();
String email = ExcelUtility.getCellData(0, 3);
objAgent.setEmail(email);
String invalidPass = ExcelUtility.getCellData(1, 2);
objAgent.setPassword(invalidPass);
objAgent.clickLogin();
Thread.sleep(2000);
String invemail=ExcelUtility.getCellData(0, 2);
objAgent.setEmail(invemail);
String passwd = ExcelUtility.getCellData(1, 3);
objAgent.setPassword(passwd);
Thread.sleep(2000);
objAgent.clickLogin();
Thread.sleep(2000);
objAgent.setEmail(invemail);
objAgent.setPassword(invalidPass);
Thread.sleep(2000);
objAgent.clickLogin();
Thread.sleep(2000);
objAgent.setEmail(email);
objAgent.setPassword(passwd);
Thread.sleep(2000);
objAgent.clickLogin();
//----------------------------------------------------------------------------------------
objAgent.linkBooking();
Thread.sleep(2000);


//----------------------------------------------------------------------------------------
objAgent.clickAddFunds();
//---------------------------------------------------------------------------------------
objAgent.clickProfile();
//----------------------------------------------------------------------------------------
objAgent.clickHome();
//--------------------------------------------------------------------------------------
objAgent.clickHotels();
//Find text field
		//WebElement searchTF = driver.findElement(By.xpath(".//*[@id='HOTELS']//*[@name='txtSearch']"));
	//	objAgent.clickSearch();
	//	String hotel="Oasis Beach Tower";
		//objAgent.clickSearchHotel(hotel);
		// Send name hotel
		//searchTF.sendKeys("Oasis Beach Tower");
		
		// Find search button
		//WebElement searchB = driver.findElement(By.xpath(".//*[@id='HOTELS']//button"));
		
		// Click search button
		//searchB.click();
		
		// Wait until title appear
		//WebDriverWait wait1 = new WebDriverWait(driver, 10);
		//wait1.until(ExpectedConditions.titleContains("Search Results"));
		
		// Verify if search result correct
	//	Assert.assertTrue(driver.findElement(By.xpath("//b[contains(.,'Oasis Beach Tower')]")).getText().equals("Oasis Beach Tower"));
objAgent.clickSearch();
Thread.sleep(2000);
String hotel="DUB";
objAgent.clickSearchHotel(hotel);
Thread.sleep(2000);
objAgent.clickSearchHotelSubmit();
Thread.sleep(2000);
objAgent.lnkFlights.click();
Thread.sleep(2000);
objAgent.lnkTours.click();
Thread.sleep(2000);
objAgent.lnkVisa.click();
Thread.sleep(2000);
objAgent.lnkBlog.click();
Thread.sleep(2000);
objAgent.lnkOffers.click();
Thread.sleep(2000);


//Thread.sleep(2000);
//String dub="Dubai,United Arab Emirates";
//objAgent.selectDubai(dub);
//objAgent.btnSearch.click();
}
}
