package com.internal.scripts;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.internal.pages.AdminFrontEndStageII;
import com.internal.pages.Login;
import com.internal.utilities.ExcelUtility;

import net.jodah.failsafe.internal.util.Assert;

public class AdminTestClass extends TestBase
{
	
	
AdminFrontEndStageII objAdmin;
@Test(priority=0)
public void verifyLogin() throws IOException, InterruptedException  {
//Create Login Page object

	objAdmin = new AdminFrontEndStageII(driver);
//login to application clickLoginLink
//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
WebDriverWait wait=new WebDriverWait(driver, 20); 
//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
	
   
    String email = ExcelUtility.getCellData(0, 4);
    Thread.sleep(2000);
    objAdmin.setEmail(email);
    String pass = ExcelUtility.getCellData(1, 4);
    Thread.sleep(2000);
    objAdmin.setPassword(pass);
    objAdmin.adminLogin();
   // Thread.sleep(2000);
    
  
   objAdmin.adminBooking();
    Thread.sleep(2000);
    
   
    // pending.getLocation();
  //  objAdmin.penToConfrm();
    objAdmin.clkCancel();
   // Thread.sleep(2000);
    objAdmin.clkCancel1();
   // objAdmin.clkCancel1();
   // cnfr.click();
  //  public WebElement password;
	
    //objAdmin.statusPaid();
    Thread.sleep(2000);
   // objAdmin.clkPaid();
    Thread.sleep(2000);

    
    
	}
/*
@Test(priority=2)
public void verifyCancel() throws IOException, InterruptedException  {
//Create Login Page object

	objAdmin = new AdminFrontEndStageII(driver);
//login to application clickLoginLink
//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
WebDriverWait wait=new WebDriverWait(driver, 20); 
//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
	
   
    String email = ExcelUtility.getCellData(0, 4);
    Thread.sleep(2000);
    objAdmin.setEmail(email);
    String pass = ExcelUtility.getCellData(1, 4);
    Thread.sleep(2000);
    objAdmin.setPassword(pass);
    objAdmin.adminLogin();
    Thread.sleep(2000);
    objAdmin.adminBooking();
    Thread.sleep(2000);
    objAdmin.clkCancel();
    Thread.sleep(2000);
    objAdmin.clkCancel1();
    
	}
@Test(priority=1)
public void verifyWeblink() throws IOException, InterruptedException  {
//Create Login Page object

	objAdmin = new AdminFrontEndStageII(driver);
//login to application clickLoginLink
//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
WebDriverWait wait=new WebDriverWait(driver, 20); 
//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
	
   
    String email = ExcelUtility.getCellData(0, 4);
    Thread.sleep(2000);
    objAdmin.setEmail(email);
    String pass = ExcelUtility.getCellData(1, 4);
    Thread.sleep(2000);
    objAdmin.setPassword(pass);
    objAdmin.adminLogin();
    Thread.sleep(2000);
    objAdmin.lnkWeb();
   // driver.quit();
    
    
	}
	*/
}
