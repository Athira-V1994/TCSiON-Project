package com.internal.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentFrontEnd {
	WebDriver driver;
	//-------------------------login-------------------------------------
		@FindBy(xpath="//body/header//div/div/div/div/div/div/a[2][text()='Login']")
		public WebElement logLink;
		@FindBy(xpath="/html/body//form/div//div/input[@type='email']")
		public WebElement email;
		@FindBy(xpath="/html/body//form/div[2]/div/input[@type='password']")
		public WebElement password;
		@FindBy(xpath="/html/body//form/div[3]/button[@type='submit']")
		public WebElement buttonLogin;
		//--------------------------logout-----------------
		
		@FindBy(xpath="//body/div/div//div[3]/ul/li[5]/a[text()=' Logout']")
		public WebElement linkLogout;
		
		//_______________________booking__________________________________________
		@FindBy(xpath="//body/div/div//div[3]/ul/li[2]/a[text()=' My Bookings']")
		public WebElement linkBooking;
		
		//----------------------Add funds--------------------------------------
		@FindBy(xpath="//body/div/div//div[3]/ul/li[3]/a[text()=' Add Funds']")
		public WebElement linkAddFunds;
		
		//---------------------My Profile
		@FindBy(xpath="//body/div/div//div[3]/ul//li[4]/a[text()=' My Profile']")
		public WebElement buttonProfile;
		
		//-------------------Home click-----------------------
		@FindBy(xpath="//header/div[2]//li/a[text()='Home']")
		public WebElement homeClick;
		//-------------------Hotels click
		@FindBy(xpath="//header/div[2]//li[2]/a[text()='Hotels']")
		public WebElement hotelsClick;
		//-----------------search-----------------------------------------------
		
		@FindBy(xpath="//span[@class='select2-selection__rendered']")
		public WebElement span;
		@FindBy(xpath="//section/section/div/div/form/div/div/div/div/div/div/select[@id='hotels_city']")
		public WebElement search;
		
		//section/section/div/div/form/div/div/div/div/div/div/select[@id='hotels_city']/option[text()=' Search by City']
		@FindBy(xpath="//h2[@class='sec__title line-height-55 bottom-line']")
		public WebElement selHotel;
		@FindBy(xpath="//input[@class='select2-search__field']")
		public WebElement select;
		@FindBy(xpath="//span[@data-select2-id='1']")
		public WebElement selectDubai;
		
		@FindBy(xpath="//button[@id='submit']")
		public WebElement btnSearch;
		//div//select[@id='hotels_city']//option[text()='Dubai,United Arab Emirates']
		@FindBy(xpath="//div//select[@id='hotels_city']//option[text()='Dubai,United Arab Emirates']")
		public WebElement searchDubai1;
		@FindBy(xpath="//span[@class='select2-results']/ul/li[text()='Dubai,United Arab Emirates']")
		public WebElement searchDubai;
		
		@FindBy(xpath="//span[@class='select2-results']")
		public WebElement spanList;
		
		@FindBy(xpath="//span[@class='select2-results']/ul/li[text()='Dublin,United States']")
		public WebElement listDub;
		////
		@FindBy(xpath="body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[2]/a[text()='Hotels']")
		public WebElement lnkHotel;
		
		
		@FindBy(xpath="//body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[3]/a[text()='flights']")
		public WebElement lnkFlights;
		
		@FindBy(xpath="//body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[4]/a[text()='Tours']")
		public WebElement lnkTours;
		
		
		
		@FindBy(xpath="//body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[5]/a[text()='visa']")
		public WebElement lnkVisa;
		
		
		@FindBy(xpath="//body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[6]/a[text()='Blog']")
		public WebElement lnkBlog;
		
		
		
		@FindBy(xpath="//body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[7]/a[text()='Offers']")
		public WebElement lnkOffers;
		
		//_______________________booking__________________________________________
		
		@FindBy(xpath="//table//a[text()=' View Voucher']")
		public WebElement linkVoucher;
		@FindBy(xpath="//button[@id='currency']")
		public WebElement linkUID;
		@FindBy(xpath="//div/div/div[2]/div/div/div/div/ul//a[text()=' INR']")
	    public WebElement linkIND;
		
		public AgentFrontEnd(WebDriver driver){
	        this.driver = driver;
	        //This initElements method will create all WebElements
	        PageFactory.initElements(driver, this);
	    }
		public void clickLoginLink(){
	        logLink.click();
	}
	    public void setEmail(String strEmail){
	    	email.clear();
	    	email.sendKeys(strEmail);     
	    }
	 //Set password in password textbox
	    public void setPassword(String strPassword){
	    	password.clear();
	       password.sendKeys(strPassword);
	    }
	    public void setInvalidEmail(String strInvalidEmail){
	    	email.clear();
	    	email.sendKeys(strInvalidEmail);     
	    }
	 //Set password in password textbox
	    public void setInvalidPassword(String strInvalidPassword){
	    	password.clear();
	       password.sendKeys(strInvalidPassword);
	    }
	    public void clickLogin(){
	    	buttonLogin.click();
	    }
		public void clickLogout(){
            linkLogout.click();
    }
		public void linkBooking() throws InterruptedException{
    		
    		linkBooking.click();
        	
        
    }
		 public void clickAddFunds() throws InterruptedException{
		    	linkAddFunds.click();		    	
		    }
		 public void clickProfile(){
		    	buttonProfile.click();
		   
		    }
		 public void clickHome(){
		    	homeClick.click();
		   
		    }
		 public void clickHotels(){
		    	hotelsClick.click();
		   
		    }
		 public void clickSearch(){
			 span.click();
		    	select.click();
		    	//btnSearch.click();
		   
		    }
		 public void clickSearchHotel(String search){
			 
		    	select.sendKeys(search);
		    	
		   
		    }
		 public void clickSearchHotelSubmit(){
			 spanList.click();
			// listDub.click();
			// selHotel.click();
			// selectDubai.click();
			 
		// searchDubai1.click();
		    	btnSearch.click();
			 
		    }
		 public void selectDubai(String search){
			 span.click();
		    	select.sendKeys(search);
		    	
		   
		    }
		 public void updateUID(){
		    	//linkBooking.click();
		    	linkUID.click();
				linkIND.click();
		   
		    }
		 
}
